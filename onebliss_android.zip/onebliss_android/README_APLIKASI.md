# Aplikasi Android ONE BLISS (panggilan layar penuh)

Aplikasi ini membungkus portal tamu (WebView) dan menambah layanan latar belakang yang menunggu panggilan resepsionis.
Saat dipanggil: dering + getar berulang dan layar panggilan PENUH (Jawab / Tolak) di atas layar kunci, seperti telepon biasa.
Tombol Jawab membuka portal dan langsung menyambungkan suara. Tolak memberi tahu resepsionis.

## 1. Membuat file APK (pilih salah satu)
**A. GitHub (tanpa memasang apa pun di komputer)**
1. Buat repositori baru di github.com, unggah ISI folder `onebliss_android` ini (termasuk folder `.github`).
2. Tab **Actions** > **Build APK** > Run workflow. Tunggu ~5 menit.
3. Buka hasil run > Artifacts > unduh `onebliss-apk` > ekstrak > `onebliss.apk`.

**B. Android Studio**: File > Open folder ini > Build > Build APK(s). Hasil: `app/build/outputs/apk/debug/app-debug.apk` (ganti nama jadi `onebliss.apk`).

## 2. Pasang di server resepsionis
1. Salin `onebliss.apk` ke `onebliss_v5_88/web/onebliss.apk`.
2. Jalankan ulang server. Alamat unduh: `https://ALAMAT-PORTAL/tamu/app.apk` (otomatis lewat Funnel).

## 3. Alur tamu (Android)
1. Scan QR pintu, masukkan kode. Muncul kotak **"Buka / pasang aplikasi"**; ketuk.
2. Belum terpasang: APK terunduh. Izinkan "pasang aplikasi dari sumber ini", pasang, lalu ketuk tombol tadi sekali lagi di browser (membawa kunci HP ke aplikasi).
3. Aplikasi meminta izin: notifikasi, mikrofon, lalu 2 pengaturan (notifikasi layar penuh, abaikan optimasi baterai). Pilih Izinkan.
4. Selesai. Panggilan resepsionis berdering layar penuh, juga saat layar terkunci atau aplikasi ditutup dari daftar terbaru.

## Catatan
- Server menahan koneksi `ringwait` (25 dtk) per HP tamu. Bila aplikasi aktif, server TIDAK mengirim push web (hindari dobel); bila aplikasi mati >40 dtk, push web jadi cadangan.
- Layanan berhenti sendiri saat sesi tamu berakhir (kunci tidak berlaku ±10 menit).
- APK ini bertanda-tangan debug (cukup untuk pasang manual). Untuk Play Store perlu keystore rilis dan justifikasi foreground service.
- iPhone: tidak bisa tanpa aplikasi iOS (akun Apple Developer + CallKit). iPhone tetap memakai notifikasi web.
- BELUM diuji di perangkat: lingkungan saya tidak punya Android SDK. Kode sudah dicek sintaksnya; uji dengan 1 HP dulu.
