package com.onebliss.tamu;

import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.app.Service;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.pm.ServiceInfo;
import android.graphics.drawable.Icon;
import android.media.AudioAttributes;
import android.media.Ringtone;
import android.media.RingtoneManager;
import android.os.Build;
import android.os.Handler;
import android.os.IBinder;
import android.os.Looper;
import android.os.PowerManager;
import android.os.VibrationEffect;
import android.os.Vibrator;

import org.json.JSONObject;

import java.io.ByteArrayOutputStream;
import java.io.InputStream;
import java.io.OutputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.net.URLEncoder;

/**
 * Menunggu panggilan resepsionis lewat long-poll ke server (/tamu/api/ringwait).
 * Saat panggilan masuk: dering + getar berulang dan notifikasi layar-penuh (CallActivity), seperti telepon.
 */
public class CallService extends Service {
    static final String CH_BG = "ob_bg", CH_CALL = "ob_call";
    static final String A_START = "com.onebliss.tamu.START", A_STOP = "com.onebliss.tamu.STOP",
            A_DECLINE = "com.onebliss.tamu.DECLINE", A_ANSWERED = "com.onebliss.tamu.ANSWERED",
            A_END = "com.onebliss.tamu.END";
    static volatile boolean appVisible = false;
    static volatile CallService inst;

    private volatile boolean run = false;
    private Thread worker;
    private volatile String base = "", ip = "", k = "";
    private volatile long handledTs = 0, activeTs = 0;
    private volatile boolean ringing = false, answered = false;
    private Ringtone ringtone;
    private Vibrator vib;
    private PowerManager.WakeLock wl;
    private final Handler ui = new Handler(Looper.getMainLooper());

    static void start(Context c) {
        c.startForegroundService(new Intent(c, CallService.class).setAction(A_START));
    }

    static void stop(Context c) {
        c.startService(new Intent(c, CallService.class).setAction(A_STOP));
    }

    /** Dipanggil MainActivity saat aplikasi masuk latar belakang: kalau panggilan masih berlangsung, bunyikan dari service. */
    static void onAppHidden() {
        final CallService s = inst;
        if (s == null) return;
        s.ui.post(new Runnable() {
            public void run() {
                if (s.activeTs != 0 && !s.ringing && !s.answered) s.showCall();
            }
        });
    }

    @Override public IBinder onBind(Intent i) { return null; }

    @Override public void onCreate() {
        super.onCreate();
        inst = this;
        NotificationManager nm = (NotificationManager) getSystemService(NOTIFICATION_SERVICE);
        NotificationChannel bg = new NotificationChannel(CH_BG, "Siaga panggilan", NotificationManager.IMPORTANCE_MIN);
        bg.setShowBadge(false);
        nm.createNotificationChannel(bg);
        NotificationChannel call = new NotificationChannel(CH_CALL, "Panggilan masuk", NotificationManager.IMPORTANCE_HIGH);
        call.setSound(null, null);
        call.enableVibration(false);
        call.setLockscreenVisibility(Notification.VISIBILITY_PUBLIC);
        nm.createNotificationChannel(call);
    }

    @Override public int onStartCommand(Intent intent, int flags, int startId) {
        String a = intent == null ? A_START : intent.getAction();
        if (a == null) a = A_START;
        if (A_STOP.equals(a)) {
            run = false;
            endRingLocal();
            stopForeground(STOP_FOREGROUND_REMOVE);
            stopSelf();
            return START_NOT_STICKY;
        }
        startFg();
        if (A_DECLINE.equals(a)) decline();
        else if (A_ANSWERED.equals(a)) { answered = true; endRingLocal(); }
        SharedPreferences sp = getSharedPreferences("ob", MODE_PRIVATE);
        base = sp.getString("base", "");
        ip = sp.getString("ip", "");
        k = sp.getString("k", "");
        if (base.length() == 0 || k.length() == 0) {
            run = false;
            stopForeground(STOP_FOREGROUND_REMOVE);
            stopSelf();
            return START_NOT_STICKY;
        }
        if (!run) startWorker();
        return START_STICKY;
    }

    @Override public void onDestroy() {
        run = false;
        endRingLocal();
        if (inst == this) inst = null;
        super.onDestroy();
    }

    private static final int FL = PendingIntent.FLAG_IMMUTABLE | PendingIntent.FLAG_UPDATE_CURRENT;

    private void startFg() {
        PendingIntent open = PendingIntent.getActivity(this, 1, new Intent(this, MainActivity.class), FL);
        Notification n = new Notification.Builder(this, CH_BG)
                .setSmallIcon(R.drawable.ic_stat)
                .setContentTitle("ONE BLISS siaga")
                .setContentText("Siap menerima panggilan resepsionis")
                .setContentIntent(open)
                .setOngoing(true)
                .build();
        if (Build.VERSION.SDK_INT >= 34) startForeground(1, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_SPECIAL_USE);
        else startForeground(1, n);
    }

    private void startWorker() {
        run = true;
        worker = new Thread(new Runnable() {
            public void run() { loop(); }
        }, "ob-ringwait");
        worker.start();
    }

    private void sleep(long ms) {
        try { Thread.sleep(ms); } catch (InterruptedException ignored) { }
    }

    private void loop() {
        long known = 0;
        int fail = 0, authFail = 0;
        while (run) {
            try {
                String u = base + "/tamu/api/ringwait?ip=" + URLEncoder.encode(ip, "UTF-8") + "&k=" + URLEncoder.encode(k, "UTF-8") + "&ts=" + known;
                JSONObject j = new JSONObject(httpGet(u, 35000));
                fail = 0;
                if (!j.optBoolean("ok")) {
                    // kunci tidak berlaku / ESP32 offline sementara. Berhenti bila terus gagal (~10 menit): masa menginap berakhir.
                    if (++authFail >= 40) { run = false; getSharedPreferences("ob", MODE_PRIVATE).edit().clear().apply(); stopSelf(); return; }
                    sleep(15000);
                    continue;
                }
                authFail = 0;
                boolean r = j.optBoolean("ringing");
                long ts = j.optLong("ts", 0);
                if (r) {
                    known = ts;
                    if (ts != handledTs) { handledTs = ts; onRing(ts); }
                } else {
                    known = 0;
                    if (activeTs != 0) { activeTs = 0; ui.post(new Runnable() { public void run() { endRingLocal(); } }); }
                }
            } catch (Exception e) {
                fail++;
                sleep(Math.min(30000, 2000L * fail));
            }
        }
    }

    private void onRing(long ts) {
        activeTs = ts;
        answered = false;
        if (appVisible) return; // halaman tamu yang sedang terbuka berdering sendiri
        ui.post(new Runnable() { public void run() { showCall(); } });
    }

    private void showCall() {
        if (ringing) return;
        ringing = true;
        NotificationManager nm = (NotificationManager) getSystemService(NOTIFICATION_SERVICE);
        PendingIntent full = PendingIntent.getActivity(this, 10, new Intent(this, CallActivity.class).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK), FL);
        PendingIntent pans = PendingIntent.getActivity(this, 12, new Intent(this, CallActivity.class).putExtra("answer", true).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK), FL);
        PendingIntent pdec = PendingIntent.getService(this, 11, new Intent(this, CallService.class).setAction(A_DECLINE), FL);
        Notification n = new Notification.Builder(this, CH_CALL)
                .setSmallIcon(R.drawable.ic_stat)
                .setContentTitle("Resepsionis memanggil Anda")
                .setContentText("ONE BLISS - ketuk untuk menjawab")
                .setCategory(Notification.CATEGORY_CALL)
                .setVisibility(Notification.VISIBILITY_PUBLIC)
                .setOngoing(true)
                .setAutoCancel(false)
                .setTimeoutAfter(120000)
                .setFullScreenIntent(full, true)
                .setContentIntent(full)
                .addAction(new Notification.Action.Builder(Icon.createWithResource(this, R.drawable.ic_stat), "Tolak", pdec).build())
                .addAction(new Notification.Action.Builder(Icon.createWithResource(this, R.drawable.ic_stat), "Jawab", pans).build())
                .build();
        nm.notify(2, n);
        try {
            PowerManager pm = (PowerManager) getSystemService(POWER_SERVICE);
            if (wl == null) wl = pm.newWakeLock(PowerManager.PARTIAL_WAKE_LOCK, "onebliss:call");
            wl.acquire(130000);
        } catch (Exception ignored) { }
        try {
            ringtone = RingtoneManager.getRingtone(this, RingtoneManager.getDefaultUri(RingtoneManager.TYPE_RINGTONE));
            if (ringtone != null) {
                ringtone.setAudioAttributes(new AudioAttributes.Builder()
                        .setUsage(AudioAttributes.USAGE_NOTIFICATION_RINGTONE)
                        .setContentType(AudioAttributes.CONTENT_TYPE_SONIFICATION).build());
                ringtone.setLooping(true);
                ringtone.play();
            }
        } catch (Exception ignored) { }
        try {
            vib = (Vibrator) getSystemService(VIBRATOR_SERVICE);
            if (vib != null) vib.vibrate(VibrationEffect.createWaveform(new long[]{0, 700, 400, 700, 400, 1000, 900}, 0));
        } catch (Exception ignored) { }
    }

    private void endRingLocal() {
        ringing = false;
        try { if (ringtone != null) { ringtone.stop(); ringtone = null; } } catch (Exception ignored) { }
        try { if (vib != null) vib.cancel(); } catch (Exception ignored) { }
        try { if (wl != null && wl.isHeld()) wl.release(); } catch (Exception ignored) { }
        try { ((NotificationManager) getSystemService(NOTIFICATION_SERVICE)).cancel(2); } catch (Exception ignored) { }
        sendBroadcast(new Intent(A_END).setPackage(getPackageName()));
    }

    private void decline() {
        endRingLocal();
        final String b = base, i = ip, kk = k;
        new Thread(new Runnable() {
            public void run() {
                try {
                    JSONObject body = new JSONObject().put("ip", i).put("k", kk).put("type", "sig").put("data", new JSONObject().put("t", "bye"));
                    httpPost(b + "/tamu/api/send", body.toString());
                } catch (Exception ignored) { }
            }
        }).start();
    }

    private static String httpGet(String u, int readTimeout) throws Exception {
        HttpURLConnection c = (HttpURLConnection) new URL(u).openConnection();
        try {
            c.setConnectTimeout(10000);
            c.setReadTimeout(readTimeout);
            c.setRequestProperty("Cache-Control", "no-store");
            return readAll(c.getInputStream());
        } finally { c.disconnect(); }
    }

    private static void httpPost(String u, String json) throws Exception {
        HttpURLConnection c = (HttpURLConnection) new URL(u).openConnection();
        try {
            c.setConnectTimeout(10000);
            c.setReadTimeout(10000);
            c.setRequestMethod("POST");
            c.setDoOutput(true);
            c.setRequestProperty("Content-Type", "application/json");
            OutputStream o = c.getOutputStream();
            o.write(json.getBytes("UTF-8"));
            o.close();
            readAll(c.getInputStream());
        } finally { c.disconnect(); }
    }

    private static String readAll(InputStream in) throws Exception {
        ByteArrayOutputStream bo = new ByteArrayOutputStream();
        byte[] buf = new byte[4096];
        int n;
        while ((n = in.read(buf)) > 0) bo.write(buf, 0, n);
        in.close();
        return bo.toString("UTF-8");
    }
}
