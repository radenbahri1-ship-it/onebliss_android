package com.onebliss.tamu;

import android.app.Activity;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.content.SharedPreferences;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.view.Gravity;
import android.view.View;
import android.view.WindowManager;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.TextView;

import java.net.URLEncoder;

/** Layar panggilan masuk penuh (tampil di atas layar kunci, menyalakan layar). */
public class CallActivity extends Activity {
    private final BroadcastReceiver endRx = new BroadcastReceiver() {
        @Override public void onReceive(Context c, Intent i) { finish(); }
    };

    @Override protected void onCreate(Bundle b) {
        super.onCreate(b);
        setShowWhenLocked(true);
        setTurnScreenOn(true);
        getWindow().addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);
        IntentFilter f = new IntentFilter(CallService.A_END);
        if (Build.VERSION.SDK_INT >= 33) registerReceiver(endRx, f, Context.RECEIVER_NOT_EXPORTED);
        else registerReceiver(endRx, f);

        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setGravity(Gravity.CENTER_HORIZONTAL);
        root.setBackgroundColor(Color.parseColor("#0A161D"));
        root.setPadding(48, 160, 48, 120);

        TextView brand = text("ONE BLISS", 16, "#E9BD5A", true);
        TextView who = text("Resepsionis memanggil Anda", 28, "#FFFFFF", true);
        TextView sub = text("Panggilan suara masuk", 16, "#9FB3BD", false);
        root.addView(brand);
        root.addView(who);
        root.addView(sub);
        View sp = new View(this);
        root.addView(sp, new LinearLayout.LayoutParams(1, 0, 1f));

        LinearLayout row = new LinearLayout(this);
        row.setOrientation(LinearLayout.HORIZONTAL);
        row.setGravity(Gravity.CENTER);
        Button no = round("Tolak", "#E5484D");
        Button yes = round("Jawab", "#2FB344");
        no.setOnClickListener(new View.OnClickListener() { public void onClick(View v) { decline(); } });
        yes.setOnClickListener(new View.OnClickListener() { public void onClick(View v) { answer(); } });
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(0, 220, 1f);
        lp.setMargins(24, 0, 24, 0);
        row.addView(no, lp);
        row.addView(yes, lp);
        root.addView(row, new LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT));
        setContentView(root);

        if (getIntent().getBooleanExtra("answer", false)) answer();
    }

    @Override protected void onNewIntent(Intent i) {
        super.onNewIntent(i);
        setIntent(i);
        if (i.getBooleanExtra("answer", false)) answer();
    }

    @Override protected void onDestroy() {
        try { unregisterReceiver(endRx); } catch (Exception ignored) { }
        super.onDestroy();
    }

    private TextView text(String s, int sp, String color, boolean bold) {
        TextView t = new TextView(this);
        t.setText(s);
        t.setTextSize(sp);
        t.setTextColor(Color.parseColor(color));
        t.setGravity(Gravity.CENTER);
        t.setPadding(0, 16, 0, 16);
        if (bold) t.setTypeface(Typeface.DEFAULT_BOLD);
        return t;
    }

    private Button round(String s, String color) {
        Button b = new Button(this);
        b.setText(s);
        b.setTextColor(Color.WHITE);
        b.setTextSize(18);
        b.setAllCaps(false);
        GradientDrawable g = new GradientDrawable();
        g.setColor(Color.parseColor(color));
        g.setCornerRadius(120);
        b.setBackground(g);
        return b;
    }

    private void decline() {
        startService(new Intent(this, CallService.class).setAction(CallService.A_DECLINE));
        finish();
    }

    private void answer() {
        startService(new Intent(this, CallService.class).setAction(CallService.A_ANSWERED));
        SharedPreferences sp = getSharedPreferences("ob", MODE_PRIVATE);
        String base = sp.getString("base", ""), ip = sp.getString("ip", ""), k = sp.getString("k", "");
        try {
            String url = base + "/tamu?ip=" + URLEncoder.encode(ip, "UTF-8") + "&auto=1&answer=1#k=" + k;
            Intent i = new Intent(this, MainActivity.class).setAction(Intent.ACTION_VIEW).setData(Uri.parse(url))
                    .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_SINGLE_TOP);
            startActivity(i);
        } catch (Exception ignored) { }
        finish();
    }
}
