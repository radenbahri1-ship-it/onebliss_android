package com.onebliss.tamu;

import android.Manifest;
import android.app.Activity;
import android.app.AlertDialog;
import android.app.NotificationManager;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.pm.PackageManager;
import android.graphics.Color;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.PowerManager;
import android.provider.Settings;
import android.view.View;
import android.view.ViewGroup;
import android.webkit.JavascriptInterface;
import android.webkit.PermissionRequest;
import android.webkit.WebChromeClient;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.Button;
import android.widget.EditText;
import android.widget.FrameLayout;
import android.widget.LinearLayout;
import android.widget.TextView;

import java.util.ArrayList;

/** Membuka portal tamu di WebView dan memberi tahu CallService sesi (alamat, IP kamar, kunci HP) yang harus ditunggu. */
public class MainActivity extends Activity {
    private WebView wv;
    private FrameLayout root;
    private View entry;
    private SharedPreferences sp;
    private PermissionRequest pendingMic;

    @Override protected void onCreate(Bundle b) {
        super.onCreate(b);
        sp = getSharedPreferences("ob", MODE_PRIVATE);
        getWindow().setStatusBarColor(Color.parseColor("#0A161D"));
        root = new FrameLayout(this);
        root.setBackgroundColor(Color.parseColor("#0A161D"));
        setContentView(root);

        wv = new WebView(this);
        WebSettings s = wv.getSettings();
        s.setJavaScriptEnabled(true);
        s.setDomStorageEnabled(true);
        s.setMediaPlaybackRequiresUserGesture(false);
        wv.setBackgroundColor(Color.parseColor("#0A161D"));
        wv.addJavascriptInterface(new Bridge(), "OBApp");
        wv.setWebViewClient(new WebViewClient() {
            @Override public boolean shouldOverrideUrlLoading(WebView v, android.webkit.WebResourceRequest r) {
                Uri u = r.getUrl();
                String cur = v.getUrl() == null ? "" : Uri.parse(v.getUrl()).getHost();
                if (u.getHost() != null && u.getHost().equals(cur)) return false;
                try { startActivity(new Intent(Intent.ACTION_VIEW, u)); } catch (Exception ignored) { }
                return true;
            }
        });
        wv.setWebChromeClient(new WebChromeClient() {
            @Override public void onPermissionRequest(final PermissionRequest req) {
                runOnUiThread(new Runnable() {
                    public void run() {
                        if (checkSelfPermission(Manifest.permission.RECORD_AUDIO) == PackageManager.PERMISSION_GRANTED) {
                            req.grant(req.getResources());
                        } else {
                            pendingMic = req;
                            requestPermissions(new String[]{Manifest.permission.RECORD_AUDIO}, 2);
                        }
                    }
                });
            }
        });
        root.addView(wv, new FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT));

        ArrayList<String> need = new ArrayList<String>();
        if (checkSelfPermission(Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED) need.add(Manifest.permission.RECORD_AUDIO);
        if (Build.VERSION.SDK_INT >= 33 && checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED) need.add(Manifest.permission.POST_NOTIFICATIONS);
        if (!need.isEmpty()) requestPermissions(need.toArray(new String[0]), 1);

        handle(getIntent());
    }

    @Override protected void onNewIntent(Intent i) {
        super.onNewIntent(i);
        setIntent(i);
        handle(i);
    }

    private void handle(Intent i) {
        Uri d = i == null ? null : i.getData();
        if (d != null && d.getHost() != null) {
            String u = d.toString();
            String noHash = u.indexOf('#') >= 0 ? u.substring(0, u.indexOf('#')) : u;
            if (noHash.indexOf("answer=1") < 0) sp.edit().putString("last", u).apply();
            showWeb(u);
            return;
        }
        String last = sp.getString("last", null);
        if (last != null) showWeb(last);
        else showEntry();
    }

    private void showWeb(String url) {
        if (entry != null) { root.removeView(entry); entry = null; }
        wv.setVisibility(View.VISIBLE);
        wv.loadUrl(url);
    }

    private void showEntry() {
        wv.setVisibility(View.GONE);
        if (entry != null) return;
        LinearLayout l = new LinearLayout(this);
        l.setOrientation(LinearLayout.VERTICAL);
        l.setPadding(48, 200, 48, 48);
        TextView t = new TextView(this);
        t.setTextColor(Color.WHITE);
        t.setTextSize(18);
        t.setText("ONE BLISS\n\nScan QR di pintu kamar dengan kamera HP, masukkan kode masuk, lalu ketuk \"Buka / pasang aplikasi\". Atau tempel tautan portal tamu di bawah.");
        l.addView(t);
        final EditText e = new EditText(this);
        e.setHint("https://.../tamu?ip=...");
        e.setTextColor(Color.WHITE);
        e.setHintTextColor(Color.GRAY);
        l.addView(e);
        Button bt = new Button(this);
        bt.setText("Buka");
        bt.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) {
                String u = e.getText().toString().trim();
                if (u.startsWith("http") && u.contains("/tamu")) { sp.edit().putString("last", u).apply(); showWeb(u); }
            }
        });
        l.addView(bt);
        entry = l;
        root.addView(l);
    }

    class Bridge {
        @JavascriptInterface public void setSession(String base, String ip, String k) {
            if (base == null || !(base.startsWith("https://") || base.startsWith("http://"))) return;
            if (k == null || !k.matches("[0-9a-f]{16}") || ip == null || ip.length() > 40) return;
            sp.edit().putString("base", base).putString("ip", ip).putString("k", k).apply();
            runOnUiThread(new Runnable() {
                public void run() {
                    try { CallService.start(MainActivity.this); } catch (Exception ignored) { }
                    nextSetup();
                }
            });
        }

        @JavascriptInterface public void clear() {
            sp.edit().remove("base").remove("ip").remove("k").apply();
            runOnUiThread(new Runnable() { public void run() { CallService.stop(MainActivity.this); } });
        }
    }

    /** Dua izin supaya layar penuh & dering tidak dimatikan sistem. Ditanyakan satu per satu, sekali saja. */
    private void nextSetup() {
        if (Build.VERSION.SDK_INT >= 34 && !sp.getBoolean("askFsi", false)) {
            NotificationManager nm = (NotificationManager) getSystemService(NOTIFICATION_SERVICE);
            sp.edit().putBoolean("askFsi", true).apply();
            if (!nm.canUseFullScreenIntent()) {
                ask("Layar panggilan penuh", "Izinkan \"Notifikasi layar penuh\" untuk ONE BLISS agar panggilan resepsionis muncul penuh di layar kunci.",
                        new Intent(Settings.ACTION_MANAGE_APP_USE_FULL_SCREEN_INTENT, Uri.parse("package:" + getPackageName())));
                return;
            }
        }
        if (!sp.getBoolean("askBat", false)) {
            sp.edit().putBoolean("askBat", true).apply();
            PowerManager pm = (PowerManager) getSystemService(POWER_SERVICE);
            if (!pm.isIgnoringBatteryOptimizations(getPackageName())) {
                ask("Tetap siaga", "Izinkan ONE BLISS berjalan tanpa pembatasan baterai agar panggilan tetap sampai saat layar mati.",
                        new Intent(Settings.ACTION_REQUEST_IGNORE_BATTERY_OPTIMIZATIONS, Uri.parse("package:" + getPackageName())));
            }
        }
    }

    private void ask(String title, String msg, final Intent go) {
        new AlertDialog.Builder(this).setTitle(title).setMessage(msg)
                .setPositiveButton("Atur", new DialogInterface.OnClickListener() {
                    public void onClick(DialogInterface d, int w) { try { startActivity(go); } catch (Exception ignored) { } }
                })
                .setNegativeButton("Nanti", null).show();
    }

    @Override public void onRequestPermissionsResult(int code, String[] perms, int[] res) {
        if (code == 2 && pendingMic != null) {
            if (res.length > 0 && res[0] == PackageManager.PERMISSION_GRANTED) pendingMic.grant(pendingMic.getResources());
            else pendingMic.deny();
            pendingMic = null;
        }
    }

    @Override protected void onResume() {
        super.onResume();
        CallService.appVisible = true;
        wv.onResume();
        if (sp.getString("k", "").length() > 0) {
            try { CallService.start(this); } catch (Exception ignored) { }
            nextSetup();
        }
    }

    @Override protected void onPause() {
        CallService.appVisible = false;
        CallService.onAppHidden();
        super.onPause();
    }

    @Override public void onBackPressed() {
        if (wv.getVisibility() == View.VISIBLE && wv.canGoBack()) wv.goBack();
        else moveTaskToBack(true);
    }
}
